#!/bin/bash

#copy ./install_licenseagent.conf to /etc/netbrain/install_licenseagent.conf
if [ ! -d "/etc/netbrain" ]; then
   mkdir "/etc/netbrain"
fi

#copy ./install_licenseagent.conf to /etc/netbrain/install_licenseagent.conf
cp -rf ./install_licenseagent.conf /etc/netbrain/install_licenseagent.conf

if [ ! -f "/etc/netbrain/install_licenseagent.conf" ]; then 
   echo "Cannot find configuration file /etc/netbrain/install_licenseagent.conf. Installation exits." 
   exit 1 
fi 

while IFS='' read -r line || [[ -n "$line" ]]; do 
   key=$(echo $line | cut -d "=" -f1) 
   value=$(echo $line | cut -d "=" -f2) 
   if [[ $key == "bind_ip" ]]; then 
      bind_ip=$value  
   elif [[ $key == "port" ]]; then 
      port=$value 
   elif [[ $key == "ssl" ]]; then  
      ssl=$value  
   elif [[ $key == "caFile" ]]; then  
      caFile=$value 
   elif [[ $key == "caKey" ]]; then  
      caKey=$value  
   fi   
done < "/etc/netbrain/install_licenseagent.conf"  

echo "ssl: $ssl"

if [ $ssl -ne 0 ]; then
   if ( echo "$caFile" | grep -q ' ' ); then
      echo "The certificate file $caFile is not specified. Installation will exit."
      exit 1 
    elif [ ! -f $caFile ]; then
      echo "The certificate file $caFile does not exist. Installation will exit."
      exit 1 
   fi

   if ( echo "$caKey" | grep -q ' ' ); then
      echo "The certificate key file $caKey is not specified. Installation will exit."
      exit 1 
    elif ! [ -f $caKey ]; then
      echo "The certificate key file $caKey does not exist. Installation will exit."
      exit 1 
   fi
fi

rpm -ivh netbrainlicense-7-0.noarch.rpm

echo "Finished to execute install.sh"
